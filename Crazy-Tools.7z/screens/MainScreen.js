import React, { useEffect, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  BackHandler,
  Platform,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { AdMobBanner } from "expo-ads-admob";

import Colors from "../constants/Colors";

// Test APP ID: ca-app-pub-3940256099942544~3347511713
// Test Banner Ad ID: ca-app-pub-3940256099942544/6300978111

// Android APP ID: ca-app-pub-2459804352307421~5875175497
// Android Banner Ad ID: ca-app-pub-2459804352307421/4370522131

// IOS APP ID: ca-app-pub-2459804352307421~5108888738
// IOS Banner Ad ID: ca-app-pub-2459804352307421/8856562059

const bannerID =
  Platform.OS === "android"
    ? "ca-app-pub-2459804352307421/4370522131"
    : "ca-app-pub-2459804352307421/8856562059";

const screenWidth = Math.round(Dimensions.get("window").width);

const MainScreen = (props) => {
  return (
    <View style={styles.screenViewContainer}>
      <View style={styles.titleContainer}>
        <Text style={styles.title}>Crazy Tools!</Text>
      </View>
      <View tyle={styles.buttonsContainer}>
        <TouchableOpacity
          style={styles.button}
          onPress={() => {
            props.navigation.navigate("PedometerScreen");
          }}
        >
          <View style={styles.buttonRow}>
            <Ionicons
              name="ios-walk"
              size={35}
              color={Colors.accent}
              style={{ marginRight: 4, marginLeft: 3 }}
            />
            <Text style={styles.buttonText}>Pedometer</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={() => {
            props.navigation.navigate("SpeedometerScreen");
          }}
        >
          <View style={styles.buttonRow}>
            <Ionicons name="ios-speedometer" size={30} color={Colors.accent} />
            <Text style={styles.buttonText}>Speedometer</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={() => {
            props.navigation.navigate("CompassScreen");
          }}
        >
          <View style={styles.buttonRow}>
            <Ionicons name="ios-compass" size={30} color={Colors.title} />
            <Text style={styles.buttonText}>Compass</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.button}
          onPress={() => {
            BackHandler.exitApp();
          }}
        >
          <View style={styles.buttonRow}>
            <Ionicons
              name="ios-close"
              size={40}
              color={Colors.accent}
              style={{ marginRight: 6, marginLeft: 4 }}
            />
            <Text style={styles.buttonText}>EXIT</Text>
          </View>
        </TouchableOpacity>
      </View>
      <View
        style={{
          flex: 1,
          justifyContent: "flex-end",
        }}
      >
        <AdMobBanner
          bannerSize="banner"
          adUnitID={bannerID} // Test ID, Replace with your-admob-unit-id
          servePersonalizedAds={false} // true or false
        />
      </View>
    </View>
  );
};

export const screenOptions = (navData) => {
  return {
    headerShown: false,
  };
};

const styles = StyleSheet.create({
  screenViewContainer: {
    flex: 1,
    backgroundColor: Colors.primary,
    justifyContent: "center",
    alignItems: "center",
  },
  titleContainer: {
    marginTop: screenWidth / 3,
    marginHorizontal: 15,
    marginBottom: screenWidth / 4,
  },
  title: {
    fontSize: screenWidth / 9,
    color: Colors.title,
    textAlign: "center",
    fontFamily: "open-sans",
  },
  buttonsContainer: {},
  buttonRow: {
    flexDirection: "row",
    marginLeft: 15,
    alignItems: "center",
  },
  button: {
    margin: 10,
    borderWidth: 1,
    borderRadius: 7,
  },
  buttonText: {
    fontFamily: "open-sans",
    fontSize: 24,
    margin: 5,
    marginHorizontal: 25,
    color: Colors.accent,
    textAlign: "center",
  },
});

export default MainScreen;
