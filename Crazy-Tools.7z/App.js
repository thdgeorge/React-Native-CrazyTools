import "react-native-gesture-handler";
import React, { useState } from "react";
import { MainNavigator } from "./navigation/MainNavigation";
import { AppLoading } from "expo";
import { Asset } from "expo-asset";
import * as Font from "expo-font";
import * as Icon from "@expo/vector-icons";

export default function App() {
  const [fontLoaded, setFontLoaded] = useState(false);

  loadLocalAsync = async () => {
    return await Promise.all([
      Asset.loadAsync([require("./assets/icon.png")]),
      Font.loadAsync({
        ...Icon.Ionicons.font,
        "open-sans": require("./assets/fonts/OpenSans-Regular.ttf"),
        "open-sans-bold": require("./assets/fonts/OpenSans-Bold.ttf"),
      }),
    ]);
  };

  handleLoadingError = (error) => {
    // In this case, you might want to report the error to your error
    // reporting service, for example Sentry
    console.warn(error);
  };

  handleFinishLoading = () => {
    setFontLoaded(true);
  };

  if (!fontLoaded) {
    return (
      <AppLoading
        startAsync={loadLocalAsync}
        onFinish={handleFinishLoading}
        onError={handleLoadingError}
      />
    );
  }

  return <MainNavigator />;
}
