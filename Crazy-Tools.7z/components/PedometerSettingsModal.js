import React from "react";
import {
  StyleSheet,
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  TextInput,
  Dimensions,
} from "react-native";
import Modal from "react-native-modal";

import Colors from "../constants/Colors";

const { height, width } = Dimensions.get("window");

const PedometerSettingsModal = (props) => {
  return (
    <Modal
      isVisible={props.show}
      onBackButtonPress={props.closeModal}
      onBackdropPress={props.closeModal}
      avoidKeyboard={true}
    >
      <View style={styles.container}>
        <ScrollView style={styles.scrollview}>
          <View>
            <Text style={styles.title}>Settings</Text>
          </View>
          <View>
            <Text style={styles.text}>Goal:</Text>
            <TextInput
              style={styles.textInput}
              onChangeText={(text) => props.onChangeText(text)}
              value={props.text}
              keyboardType="numeric"
              maxLength={10}
            />
          </View>
          <View style={{ alignItems: "center" }}>
            <TouchableOpacity
              style={styles.saveButton}
              onPress={props.onSubmit}
            >
              <Text style={styles.saveButtonText}>Save</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    height: "60%",
    width: "80%",
    borderRadius: 16,
    alignSelf: "center",
    backgroundColor: Colors.primary,
    overflow: "hidden",
  },
  scrollview: {},
  title: {
    color: Colors.accent,
    fontSize: height / 32,
    fontFamily: "open-sans-bold",
    paddingTop: 25,
    paddingBottom: 25,
    marginHorizontal: 25,
    textAlign: "center",
  },
  text: {
    color: Colors.accent,
    fontSize: height / 40,
    fontFamily: "open-sans",
    paddingTop: 10,
    paddingBottom: 5,
    marginHorizontal: 30,
  },
  textInput: {
    height: 40,
    fontSize: height / 40,
    fontFamily: "open-sans",
    borderColor: "#888",
    borderWidth: 1,
    marginHorizontal: 25,
    borderRadius: 7,
    paddingHorizontal: 10,
    color: Colors.accent,
  },
  saveButton: {
    height: 50,
    width: "60%",
    borderRadius: 16,
    backgroundColor: Colors.secondary,
    justifyContent: "center",
    marginVertical: 50,
  },
  saveButtonText: {
    color: Colors.white,
    fontSize: height / 35,
    textAlign: "center",
    fontFamily: "open-sans",
  },
});

export default PedometerSettingsModal;
