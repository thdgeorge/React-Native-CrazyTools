export default {
  primary: "#262626",
  accent: "#FFFFFF",
  secondary: "#6d0000",
  scrollview: "#262626",
  title: "#D3D3D3",
  hint: "#FFBF00",
  blue: "#51e2f5",
  softGrey: "#888",

  white: "#FFFFFF",
  black: "#000000",
};
