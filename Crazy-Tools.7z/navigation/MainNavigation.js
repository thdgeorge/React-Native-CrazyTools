import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

import Colors from "../constants/Colors";

import MainScreen, {
  screenOptions as MainScreenOptions,
} from "../screens/MainScreen";
import PedometerScreen, {
  screenOptions as PedometerScreenOptions,
} from "../screens/PedometerScreen";
import SpeedometerScreen, {
  screenOptions as SpeedometerScreenOptions,
} from "../screens/SpeedometerScreen";
import CompassScreen, {
  screenOptions as CompassScreenOptions,
} from "../screens/CompassScreen";

const defaultNavOptions = {
  headerStyle: {
    backgroundColor: Colors.primary,
    elevation: 0,
  },
  headerTitleStyle: {
    fontFamily: "open-sans-bold",
  },
  headerBackTitleStyle: {
    fontFamily: "open-sans",
  },
  headerTintColor: Colors.accent,
};

const MainStackNavigator = createStackNavigator();

export const MainNavigator = () => {
  return (
    <NavigationContainer>
      <MainStackNavigator.Navigator
        screenOptions={defaultNavOptions}
        initialRouteName="MainScreen"
      >
        <MainStackNavigator.Screen
          name="MainScreen"
          component={MainScreen}
          options={MainScreenOptions}
        />
        <MainStackNavigator.Screen
          name="PedometerScreen"
          component={PedometerScreen}
          options={PedometerScreenOptions}
          initialParams={{ showSettingsModal: false }}
        />
        <MainStackNavigator.Screen
          name="SpeedometerScreen"
          component={SpeedometerScreen}
          options={SpeedometerScreenOptions}
          initialParams={{ showSettingsModal: false }}
        />
        <MainStackNavigator.Screen
          name="CompassScreen"
          component={CompassScreen}
          options={CompassScreenOptions}
        />
      </MainStackNavigator.Navigator>
    </NavigationContainer>
  );
};
