import React, { useState, useEffect } from "react";
import { StyleSheet, Text, View, Dimensions, AsyncStorage } from "react-native";
import * as Location from "expo-location";
import { HeaderButtons, Item } from "react-navigation-header-buttons";
import HeaderButton from "../components/HeaderButton";
import { AnimatedCircularProgress } from "react-native-circular-progress";
import { Ionicons } from "@expo/vector-icons";
import SpeedometerSettingsModal from "../components/SpeedometerSettingsModal";
import { AdMobBanner } from "expo-ads-admob";

import Colors from "../constants/Colors";

// Test APP ID: ca-app-pub-3940256099942544~3347511713
// Test Banner Ad ID: ca-app-pub-3940256099942544/6300978111

// Android APP ID: ca-app-pub-2459804352307421~5875175497
// Android Banner Ad ID: ca-app-pub-2459804352307421/7975258050

// IOS APP ID: ca-app-pub-2459804352307421~5108888738
// IOS Banner Ad ID: ca-app-pub-2459804352307421/8382452164

const bannerID =
  Platform.OS === "android"
    ? "ca-app-pub-2459804352307421/7975258050"
    : "ca-app-pub-2459804352307421/8382452164";

const { height, width } = Dimensions.get("window");

const SpeedometerScreen = (props) => {
  const [isSpeedometerAvailable, setIsSpeedometerAvailable] = useState(
    "checking"
  );
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [text, setText] = useState("");
  const [maxSpeed, setMaxSpeed] = useState(240);

  const [location, setLocation] = useState(null);
  const [errorMsg, setErrorMsg] = useState(null);

  let subscription = null;

  useEffect(() => {
    checkMaxSpeed();
    subscribe();

    return () => {
      unsubscribe();
    };
  }, []);

  const checkMaxSpeed = async () => {
    try {
      let MAX_SPEED = await AsyncStorage.getItem("MAX_SPEED");
      if (MAX_SPEED !== null) {
        setMaxSpeed(MAX_SPEED);
        setText(MAX_SPEED.toString());
      } else {
        setMaxSpeed(240);
        setText("240");
      }
    } catch (error) {
      // Error retrieving data
    }
  };

  const saveMaxSpeed = async () => {
    try {
      await AsyncStorage.setItem("MAX_SPEED", text);
    } catch (error) {
      // Error saving data
    }
  };

  useEffect(() => {
    props.navigation.setParams({
      setShowSettingsModal: setShowSettingsModal,
    });
  }, [showSettingsModal]);

  const subscribe = async () => {
    let { status } = await Location.requestPermissionsAsync();
    if (status !== "granted") {
      setErrorMsg("Permission to access location was denied");
    }

    subscription = await Location.watchPositionAsync(
      { accuracy: 5, timeout: 300, distanceInterval: 0 },
      (tempLocation) => {
        setLocation(tempLocation);
      }
    );
  };

  const unsubscribe = () => {
    subscription && subscription.remove();
    subscription = null;
  };

  const onSubmit = () => {
    setMaxSpeed(Number(text));
    setShowSettingsModal(false);
    saveMaxSpeed();
  };

  // useEffect(() => {
  //   (async () => {
  //     let { status } = await Location.requestPermissionsAsync();
  //     if (status !== "granted") {
  //       setErrorMsg("Permission to access location was denied");
  //     }

  //     let tempLocation = await Location.getCurrentPositionAsync({});
  //     setLocation(tempLocation);
  //   })();
  // });

  // let text = "Waiting...";
  // let speed = 0;
  let carSpeed = 0;
  // let carSpeedRounded = 0;

  if (errorMsg) {
    // text = errorMsg;
  } else if (location) {
    // text = JSON.stringify(location);
    // speed = location.coords.speed;
    carSpeed = location.coords.speed * 3.6;
    // carSpeedRounded = Math.round(location.coords.speed * 3.6);
  }

  return (
    <View style={styles.container}>
      {/* <Text
        style={{
          fontSize: height / 50,
          textAlign: "center",
          paddingTop: 75,
          paddingBottom: 15,
          color: Colors.accent,
        }}
      >
        {text}
      </Text>
      <Text
        style={{
          fontSize: height / 40,
          textAlign: "center",
          paddingVertical: 15,
          color: Colors.accent,
        }}
      >
        Speed (m/s): {speed}
      </Text> */}
      {/* <Text
        style={{
          fontSize: height / 40,
          textAlign: "center",
          paddingBottom: 30,
          color: Colors.accent,
        }}
      >
        Speed (Km/h): {carSpeed}
      </Text> */}

      <View
        style={{
          flex: 0.9,
          alignItems: "center",
          justifyContent: "center",
          marginTop: width / 10,
        }}
      >
        <AnimatedCircularProgress
          size={height / 2.5}
          width={15}
          fill={(carSpeed / maxSpeed) * 100}
          tintColor={Colors.secondary}
          backgroundColor={Colors.softGrey}
          arcSweepAngle={240}
          rotation={240}
        >
          {(fill) => (
            <Text
              style={{
                fontSize: height / 12,
                fontFamily: "open-sans-bold",
                textAlign: "center",
                color: Colors.accent,
              }}
            >
              {Math.round((fill * maxSpeed) / 100)}
            </Text>
          )}
        </AnimatedCircularProgress>
        <Ionicons
          name="ios-speedometer"
          size={height / 20}
          color={Colors.accent}
          style={{
            position: "absolute",
            paddingBottom: 150,
          }}
        />
        <Text
          style={{
            fontSize: height / 35,
            textAlign: "center",
            position: "absolute",
            paddingTop: 150,
            color: Colors.softGrey,
          }}
        >
          Km/h
        </Text>
      </View>
      <SpeedometerSettingsModal
        show={showSettingsModal}
        closeModal={() => {
          setShowSettingsModal(false);
        }}
        text={text}
        onChangeText={(text) => {
          setText(text);
        }}
        onSubmit={onSubmit}
      ></SpeedometerSettingsModal>
      <View
        style={{
          flex: 0.1,
          justifyContent: "flex-end",
        }}
      >
        <AdMobBanner
          bannerSize="banner"
          adUnitID={bannerID} // Test ID, Replace with your-admob-unit-id
          servePersonalizedAds={false} // true or false
        />
      </View>
    </View>
  );
};

export const screenOptions = (navData) => {
  const setShowSettingsModal = navData.route.params.setShowSettingsModal;

  return {
    headerTitle: "Speedometer",

    headerRight: () => (
      <HeaderButtons HeaderButtonComponent={HeaderButton}>
        <Item
          title="Settings"
          color={Colors.white}
          iconName={"ios-settings"}
          onPress={() => {
            setShowSettingsModal(true);
          }}
        />
      </HeaderButtons>
    ),
  };
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.primary,
  },
  text: {
    fontSize: height / 40,
    fontFamily: "open-sans",
    textAlign: "center",
    color: Colors.accent,
    paddingTop: height / 10,
    paddingBottom: height / 10,
  },
});

export default SpeedometerScreen;
