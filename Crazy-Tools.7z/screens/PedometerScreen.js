import React, { useState, useEffect } from "react";
import { StyleSheet, AsyncStorage, Text, View, Dimensions } from "react-native";
import { Pedometer } from "expo-legacy"; // Instead of expo-sensors (getStepCountAsync(start, end))
import { AnimatedCircularProgress } from "react-native-circular-progress";
import { HeaderButtons, Item } from "react-navigation-header-buttons";
import HeaderButton from "../components/HeaderButton";
import PedometerSettingsModal from "../components/PedometerSettingsModal";
import { Ionicons } from "@expo/vector-icons";
import { AdMobBanner } from "expo-ads-admob";

import Colors from "../constants/Colors";

// Test APP ID: ca-app-pub-3940256099942544~3347511713
// Test Banner Ad ID: ca-app-pub-3940256099942544/6300978111

// Android APP ID: ca-app-pub-2459804352307421~5875175497
// Android Banner Ad ID: ca-app-pub-2459804352307421/2708465411

// IOS APP ID: ca-app-pub-2459804352307421~5108888738
// IOS Banner Ad ID: ca-app-pub-2459804352307421/1395383746

const bannerID =
  Platform.OS === "android"
    ? "ca-app-pub-2459804352307421/2708465411"
    : "ca-app-pub-2459804352307421/1395383746";

const { height, width } = Dimensions.get("window");

const PedometerScreen = (props) => {
  const [isPedometerAvailable, setIsPedometerAvailable] = useState("checking");
  const [pastStepCount, setPastStepCount] = useState(0);
  const [currentStepCount, setCurrentStepCount] = useState(0);
  const [goal, setGoal] = useState(0);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [text, setText] = useState("");

  let subscription = null;

  useEffect(() => {
    checkGoal();
    subscribe();
    return () => {
      unsubscribe();
    };
  }, []);

  const checkGoal = async () => {
    try {
      let GOAL = await AsyncStorage.getItem("GOAL");
      if (GOAL !== null) {
        setGoal(GOAL);
        setText(GOAL.toString());
      } else {
        setGoal(3000);
        setText("3000");
      }
    } catch (error) {
      // Error retrieving data
    }
  };

  const saveGoal = async () => {
    try {
      await AsyncStorage.setItem("GOAL", text);
    } catch (error) {
      // Error saving data
    }
  };

  useEffect(() => {
    props.navigation.setParams({
      setShowSettingsModal: setShowSettingsModal,
    });
  }, [showSettingsModal]);

  const subscribe = () => {
    subscription = Pedometer.watchStepCount((result) => {
      setCurrentStepCount(result.steps);
      console.log("currentStepCount: " + result.steps);
    });

    Pedometer.isAvailableAsync().then(
      (result) => {
        setIsPedometerAvailable(String(result));
      },
      (error) => {
        setIsPedometerAvailable("Could not get isPedometerAvailable: " + error);
      }
    );

    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - 1);
    Pedometer.getStepCountAsync(start, end).then(
      (result) => {
        setPastStepCount(result.steps);
        console.log("pastStepCount: " + result.steps);
      },
      (error) => {
        setPastStepCount("Could not get stepCount: " + error);
      }
    );
  };

  const unsubscribe = () => {
    subscription && subscription.remove();
    subscription = null;
  };

  const onSubmit = () => {
    setGoal(Number(text));
    setShowSettingsModal(false);
    saveGoal();
  };

  return (
    <View style={styles.container}>
      {/* <Text
        style={{
          fontSize: height / 46,
          textAlign: "center",
          paddingVertical: 5,
        }}
      >
        Pedometer.isAvailableAsync(): {isPedometerAvailable}
      </Text>
      <Text
        style={{
          fontSize: height / 46,
          textAlign: "center",
          paddingVertical: 5,
        }}
      >
        Steps taken in the last 24 hours: {pastStepCount}
      </Text>
      <Text
        style={{
          fontSize: height / 36,
          fontWeight: "bold",
          textAlign: "center",
          paddingVertical: 5,
          paddingBottom: 45,
        }}
      >
        Walk! And watch this go up: {currentStepCount}
      </Text> */}

      <View style={{ alignItems: "center", justifyContent: "center" }}>
        <Text style={styles.text}>Steps taken in the last 24 hours</Text>
      </View>

      <View style={{ alignItems: "center", justifyContent: "center" }}>
        <AnimatedCircularProgress
          size={height / 2.5}
          width={7}
          fill={((pastStepCount + currentStepCount) / goal) * 100}
          tintColor={Colors.blue}
          backgroundColor={Colors.softGrey}
          rotation={0}
        >
          {(fill) => (
            <Text
              style={{
                fontSize: height / 12,
                fontFamily: "open-sans-bold",
                textAlign: "center",
                color: Colors.accent,
              }}
            >
              {Math.round((fill * goal) / 100)}
            </Text>
          )}
        </AnimatedCircularProgress>
        <Ionicons
          name="ios-walk"
          size={height / 20}
          color={Colors.accent}
          style={{
            position: "absolute",
            paddingBottom: 150,
          }}
        />
        <Text
          style={{
            fontSize: height / 35,
            textAlign: "center",
            position: "absolute",
            paddingTop: 150,
            color: Colors.softGrey,
          }}
        >
          GOAL: {goal}
        </Text>
      </View>
      <PedometerSettingsModal
        show={showSettingsModal}
        closeModal={() => {
          setShowSettingsModal(false);
        }}
        text={text}
        onChangeText={(text) => {
          setText(text);
        }}
        onSubmit={onSubmit}
      ></PedometerSettingsModal>
      <View
        style={{
          flex: 1,
          justifyContent: "flex-end",
        }}
      >
        <AdMobBanner
          bannerSize="banner"
          adUnitID={bannerID} // Test ID, Replace with your-admob-unit-id
          servePersonalizedAds={false} // true or false
        />
      </View>
    </View>
  );
};

export const screenOptions = (navData) => {
  const setShowSettingsModal = navData.route.params.setShowSettingsModal;

  return {
    headerTitle: "Pedometer",

    headerRight: () => (
      <HeaderButtons HeaderButtonComponent={HeaderButton}>
        <Item
          title="Settings"
          color={Colors.white}
          iconName={"ios-settings"}
          onPress={() => {
            setShowSettingsModal(true);
          }}
        />
      </HeaderButtons>
    ),
  };
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    // justifyContent: "center",
    backgroundColor: Colors.primary,
  },
  text: {
    fontSize: height / 40,
    fontFamily: "open-sans",
    textAlign: "center",
    color: Colors.accent,
    paddingTop: height / 10,
    paddingBottom: height / 10,
  },
});

export default PedometerScreen;
