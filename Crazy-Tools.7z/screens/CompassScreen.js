// https://github.com/rahulhaque/compass-react-native-expo

import React, { useState, useEffect } from "react";
import { Image, View, Text, Dimensions, StyleSheet } from "react-native";
import { Magnetometer } from "expo-sensors";
import { AdMobBanner } from "expo-ads-admob";

import Colors from "../constants/Colors";

// Test APP ID: ca-app-pub-3940256099942544~3347511713
// Test Banner Ad ID: ca-app-pub-3940256099942544/6300978111

// Android APP ID: ca-app-pub-2459804352307421~5875175497
// Android Banner Ad ID: ca-app-pub-2459804352307421/3963328022

// IOS APP ID: ca-app-pub-2459804352307421~5108888738
// IOS Banner Ad ID: ca-app-pub-2459804352307421/4443207156

const bannerID =
  Platform.OS === "android"
    ? "ca-app-pub-2459804352307421/3963328022"
    : "ca-app-pub-2459804352307421/4443207156";

const { height, width } = Dimensions.get("window");

const CompassScreen = (props) => {
  //   const [subscription, setSubscription] = useState(null);
  const [magnetometer, setMagnetometer] = useState(0);
  let subscription = null;

  useEffect(() => {
    toggle();
    return () => {
      unsubscribe();
    };
  }, []);

  const toggle = () => {
    if (subscription) {
      unsubscribe();
    } else {
      subscribe();
    }
  };

  const subscribe = () => {
    subscription = Magnetometer.addListener((data) => {
      setMagnetometer(angle(data));
    });
  };

  const unsubscribe = () => {
    subscription && subscription.remove();
    subscription = null;
  };

  const angle = (magnetometer) => {
    let tempAngle = null;
    if (magnetometer) {
      let { x, y, z } = magnetometer;

      if (Math.atan2(y, x) >= 0) {
        tempAngle = Math.atan2(y, x) * (180 / Math.PI);
      } else {
        tempAngle = (Math.atan2(y, x) + 2 * Math.PI) * (180 / Math.PI);
      }
    }

    return Math.round(tempAngle);
  };

  const direction = (degree) => {
    if (degree >= 22.5 && degree < 67.5) {
      return "NE";
    } else if (degree >= 67.5 && degree < 112.5) {
      return "E";
    } else if (degree >= 112.5 && degree < 157.5) {
      return "SE";
    } else if (degree >= 157.5 && degree < 202.5) {
      return "S";
    } else if (degree >= 202.5 && degree < 247.5) {
      return "SW";
    } else if (degree >= 247.5 && degree < 292.5) {
      return "W";
    } else if (degree >= 292.5 && degree < 337.5) {
      return "NW";
    } else {
      return "N";
    }
  };

  // Match the device top with pointer 0° degree. (By default 0° starts from the right of the device.)
  const degree = (magnetometer) => {
    return magnetometer - 90 >= 0 ? magnetometer - 90 : magnetometer + 271;
  };

  return (
    <View style={styles.container}>
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
        <Text
          style={{
            color: Colors.accent,
            fontSize: height / 26,
            fontWeight: "bold",
            textAlign: "center",
          }}
        >
          {direction(degree(magnetometer))}
        </Text>
      </View>

      <View style={{ flex: 3 }}>
        <View
          style={{
            width: width,
            alignItems: "center",
          }}
        >
          <Image
            source={require("../assets/compass_pointer.png")}
            style={{
              height: height / 26,
              resizeMode: "contain",
            }}
          />
        </View>

        <View style={{ alignItems: "center", justifyContent: "center" }}>
          <Text
            style={{
              color: Colors.accent,
              fontSize: height / 27,
              width: width,
              position: "absolute",
              textAlign: "center",
            }}
          >
            {degree(magnetometer)}°
          </Text>

          <Image
            source={require("../assets/compass_bg.png")}
            style={{
              height: width - 80,
              resizeMode: "contain",
              transform: [{ rotate: 360 - magnetometer + "deg" }],
            }}
          />
        </View>
      </View>
      <View
        style={{
          justifyContent: "flex-end",
          alignItems: "center",
        }}
      >
        <AdMobBanner
          bannerSize="banner"
          adUnitID={bannerID} // Test ID, Replace with your-admob-unit-id
          servePersonalizedAds={false} // true or false
        />
      </View>
    </View>
  );
};

export const screenOptions = (navData) => {
  return {
    headerTitle: "Compass",
  };
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary,
    justifyContent: "center",
  },
});

export default CompassScreen;
